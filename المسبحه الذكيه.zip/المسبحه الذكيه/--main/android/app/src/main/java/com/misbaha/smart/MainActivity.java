package com.misbaha.smart;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
